import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Request, Match, Category, RequestType } from './types';

// Генерация ID
const generateId = () => Math.random().toString(36).substring(2, 15);

interface AppState {
  // User
  user: User | null;
  setUser: (user: User | null) => void;
  
  // Requests
  requests: Request[];
  myRequests: Request[];
  addRequest: (request: Omit<Request, 'id' | 'createdAt' | 'status' | 'matchesCount'>) => Request;
  updateRequest: (id: string, updates: Partial<Request>) => void;
  deleteRequest: (id: string) => void;
  
  // Matches
  matches: Match[];
  addMatch: (match: Omit<Match, 'id' | 'createdAt'>) => void;
  updateMatch: (id: string, updates: Partial<Match>) => void;
  
  // UI State
  isLoading: boolean;
  setLoading: (loading: boolean) => void;
  
  // Filters
  filters: {
    category?: Category;
    region?: string;
    type?: RequestType;
  };
  setFilters: (filters: AppState['filters']) => void;
}

// Моковые данные для демо
const mockRequests: Request[] = [
  {
    id: '1',
    userId: 'user1',
    type: 'buy',
    category: 'construction',
    title: 'Цемент М500 оптом',
    description: 'Нужен цемент М500 для строительного объекта в Москве. Доставка на объект.',
    volume: '500',
    unit: 'тонн',
    budget: 2500000,
    region: 'Москва',
    status: 'active',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    matchesCount: 3,
  },
  {
    id: '2',
    userId: 'user2',
    type: 'sell',
    category: 'metal',
    title: 'Арматура А500С ⌀12мм',
    description: 'Продаём арматуру со склада в Подмосковье. Сертификаты в наличии.',
    volume: '200',
    unit: 'тонн',
    price: 65000,
    region: 'Московская область',
    status: 'active',
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
    matchesCount: 7,
  },
  {
    id: '3',
    userId: 'user3',
    type: 'buy',
    category: 'wood',
    title: 'Доска обрезная 50х150',
    description: 'Ищем поставщика доски обрезной для мебельного производства.',
    volume: '100',
    unit: 'м³',
    budget: 1800000,
    region: 'Краснодарский край',
    status: 'active',
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
    matchesCount: 2,
  },
  {
    id: '4',
    userId: 'user4',
    type: 'sell',
    category: 'equipment',
    title: 'Экскаватор CAT 320D',
    description: 'Продаём экскаватор 2019 года, наработка 3500 моточасов. Отличное состояние.',
    volume: '1',
    unit: 'шт',
    price: 12000000,
    region: 'Ростовская область',
    status: 'active',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    matchesCount: 5,
  },
  {
    id: '5',
    userId: 'user5',
    type: 'buy',
    category: 'chemicals',
    title: 'Полиэтилен высокого давления',
    description: 'Нужен ПВД для производства плёнки. Регулярные закупки.',
    volume: '50',
    unit: 'тонн/мес',
    budget: 7500000,
    region: 'Татарстан',
    status: 'active',
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    matchesCount: 1,
  },
];

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // User
      user: null,
      setUser: (user) => set({ user }),
      
      // Requests
      requests: mockRequests,
      myRequests: [],
      
      addRequest: (requestData) => {
        const newRequest: Request = {
          ...requestData,
          id: generateId(),
          createdAt: new Date(),
          status: 'active',
          matchesCount: 0,
        };
        set((state) => ({
          requests: [newRequest, ...state.requests],
          myRequests: [newRequest, ...state.myRequests],
        }));
        return newRequest;
      },
      
      updateRequest: (id, updates) => {
        set((state) => ({
          requests: state.requests.map((r) => r.id === id ? { ...r, ...updates } : r),
          myRequests: state.myRequests.map((r) => r.id === id ? { ...r, ...updates } : r),
        }));
      },
      
      deleteRequest: (id) => {
        set((state) => ({
          requests: state.requests.filter((r) => r.id !== id),
          myRequests: state.myRequests.filter((r) => r.id !== id),
        }));
      },
      
      // Matches
      matches: [],
      
      addMatch: (matchData) => {
        const newMatch: Match = {
          ...matchData,
          id: generateId(),
          createdAt: new Date(),
        };
        set((state) => ({ matches: [...state.matches, newMatch] }));
      },
      
      updateMatch: (id, updates) => {
        set((state) => ({
          matches: state.matches.map((m) => m.id === id ? { ...m, ...updates } : m),
        }));
      },
      
      // UI
      isLoading: false,
      setLoading: (isLoading) => set({ isLoading }),
      
      // Filters
      filters: {},
      setFilters: (filters) => set({ filters }),
    }),
    {
      name: 'commerce-storage',
      partialize: (state) => ({ 
        user: state.user,
        myRequests: state.myRequests,
      }),
    }
  )
);
